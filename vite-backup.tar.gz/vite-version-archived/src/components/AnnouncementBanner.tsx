export function AnnouncementBanner() {
  return (
    <div className="bg-black text-white py-[10px] overflow-hidden relative">
      <div className="flex gap-[10px] animate-[scroll-left_15s_linear_infinite] whitespace-nowrap">
        <span className="text-[0.9em] font-medium tracking-[0.05em]"><span className="text-[#4ade80] text-[1.15em] font-bold">$395</span> • Insurance Eligible -</span>
        <span className="text-[0.9em] font-medium tracking-[0.05em]">HSA/FSA Accepted -</span>
        <span className="text-[0.9em] font-medium tracking-[0.05em]"><span className="text-[#4ade80] text-[1.15em] font-bold">$66/mo</span> Financing -</span>
        <span className="text-[0.9em] font-medium tracking-[0.05em]">30-Day Guarantee -</span>
        <span className="text-[0.9em] font-medium tracking-[0.05em]"><span className="text-[#4ade80] text-[1.15em] font-bold">$395</span> • Insurance Eligible -</span>
        <span className="text-[0.9em] font-medium tracking-[0.05em]">HSA/FSA Accepted -</span>
        <span className="text-[0.9em] font-medium tracking-[0.05em]"><span className="text-[#4ade80] text-[1.15em] font-bold">$66/mo</span> Financing -</span>
        <span className="text-[0.9em] font-medium tracking-[0.05em]">30-Day Guarantee -</span>
      </div>
    </div>
  );
}
