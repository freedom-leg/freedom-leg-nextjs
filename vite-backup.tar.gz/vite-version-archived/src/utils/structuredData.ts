import type { Injury } from '../types/injury';

export function generateMedicalConditionSchema(injury: Injury, siteUrl: string = 'https://freedomleg.com') {
  return {
    '@context': 'https://schema.org',
    '@type': 'MedicalCondition',
    name: injury.injury_name,
    alternateName: injury.common_name,
    description: injury.full_description || injury.short_description,
    ...(injury.how_freedom_leg_helps && {
      possibleTreatment: {
        '@type': 'MedicalTherapy',
        name: 'Freedom Leg Hands-Free Crutch',
        description: injury.how_freedom_leg_helps,
      },
    }),
    ...(injury.ideal_candidate_description && {
      riskFactor: injury.ideal_candidate_description,
    }),
    url: `${siteUrl}/conditions/${injury.slug}`,
  };
}

export function generateFAQSchema(faqItems: Array<{ question: string; answer: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqItems.map((faq) => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer,
      },
    })),
  };
}

export function generateBreadcrumbSchema(items: Array<{ name: string; url: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: item.url,
    })),
  };
}

export function generateOrganizationSchema(siteUrl: string = 'https://freedomleg.com') {
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Freedom Leg',
    url: siteUrl,
    logo: `${siteUrl}/logo.png`,
    description: 'Freedom Leg provides hands-free mobility solutions for foot, ankle, lower leg, and knee injuries requiring non-weight bearing recovery.',
    sameAs: [
      'https://www.facebook.com/freedomleg',
      'https://www.instagram.com/freedomleg',
      'https://www.youtube.com/freedomleg',
    ],
  };
}

export function generateProductSchema(siteUrl: string = 'https://freedomleg.com') {
  return {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: 'Freedom Leg Hands-Free Crutch',
    description: 'A revolutionary hands-free mobility device that provides complete off-loading for foot, ankle, lower leg, and knee injuries. Walk naturally with both hands free.',
    brand: {
      '@type': 'Brand',
      name: 'Freedom Leg',
    },
    image: `${siteUrl}/product-image.jpg`,
    url: siteUrl,
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '4.8',
      reviewCount: '2450',
    },
    offers: {
      '@type': 'Offer',
      url: siteUrl,
      priceCurrency: 'USD',
      price: '399.00',
      availability: 'https://schema.org/InStock',
      seller: {
        '@type': 'Organization',
        name: 'Freedom Leg',
      },
    },
  };
}
