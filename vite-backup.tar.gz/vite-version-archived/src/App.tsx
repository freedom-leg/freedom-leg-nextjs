import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { Gallery } from './pages/Gallery';
import { ModalVersion } from './pages/ModalVersion';
import { InlineVersion } from './pages/InlineVersion';
import { HybridVersion } from './pages/HybridVersion';
import { AchillesRupturePage } from './pages/AchillesRupturePage';
import { FootAnkleFracturePage } from './pages/FootAnkleFracturePage';
import { KneeSurgeryPage } from './pages/KneeSurgeryPage';
import { LowerLegFracturePage } from './pages/LowerLegFracturePage';
import { FootSurgeryPage } from './pages/FootSurgeryPage';

console.log('🚀 Freedom Leg App - Static SEO Build -', new Date().toISOString());

function App() {
  return (
    <HelmetProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Gallery />} />
          <Route path="/modal" element={<ModalVersion />} />
          <Route path="/inline" element={<InlineVersion />} />
          <Route path="/hybrid" element={<HybridVersion />} />
          <Route path="/achilles-rupture" element={<AchillesRupturePage />} />
          <Route path="/foot-ankle-fractures" element={<FootAnkleFracturePage />} />
          <Route path="/knee-surgery" element={<KneeSurgeryPage />} />
          <Route path="/lower-leg-fracture" element={<LowerLegFracturePage />} />
          <Route path="/foot-surgery" element={<FootSurgeryPage />} />
        </Routes>
      </BrowserRouter>
    </HelmetProvider>
  );
}

export default App;
