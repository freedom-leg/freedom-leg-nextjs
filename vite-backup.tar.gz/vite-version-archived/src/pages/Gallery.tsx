import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { SEO } from '../components/SEO';
import { generateOrganizationSchema } from '../utils/structuredData';
import { LANDING_PAGE_INJURIES } from '../data/injuries';

export function Gallery() {
  const versions = [
    {
      id: 'modal',
      name: 'Modal Version',
      description: 'Content displayed in interactive modals with sticky footer navigation',
      path: '/modal',
    },
    {
      id: 'inline',
      name: 'Inline Version',
      description: 'All content displayed inline in a single scrollable page',
      path: '/inline',
    },
    {
      id: 'hybrid',
      name: 'Hybrid Version',
      description: 'Combines inline content sections with modal interactions for key features',
      path: '/hybrid',
    },
  ];

  const injuryPages = [
    { ...LANDING_PAGE_INJURIES.achilles, path: '/achilles-rupture' },
    { ...LANDING_PAGE_INJURIES.footAnkleFracture, path: '/foot-ankle-fractures' },
    { ...LANDING_PAGE_INJURIES.kneeSurgery, path: '/knee-surgery' },
    { ...LANDING_PAGE_INJURIES.lowerLegFracture, path: '/lower-leg-fracture' },
    { ...LANDING_PAGE_INJURIES.footSurgery, path: '/foot-surgery' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <SEO
        title="Freedom Leg - Hands-Free Mobility for Injury Recovery"
        description="Revolutionary hands-free crutch alternative. Complete off-loading for foot, ankle, lower leg, and knee injuries. Walk naturally with both hands free during recovery."
        canonical="https://freedomleg.com"
        structuredData={generateOrganizationSchema()}
      />
      <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Website Version Gallery
          </h1>
          <p className="text-lg text-gray-600">
            Click any version below to open it in a new window
          </p>
        </div>

        <div className="space-y-6">
          {versions.map((version) => (
            <a
              key={version.id}
              href={version.path}
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 p-6 border-2 border-gray-100 hover:border-blue-500"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h2 className="text-2xl font-semibold text-gray-900 mb-2">
                    {version.name}
                  </h2>
                  <p className="text-gray-600">
                    {version.description}
                  </p>
                </div>
                <svg
                  className="w-6 h-6 text-gray-400 flex-shrink-0 ml-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                  />
                </svg>
              </div>
            </a>
          ))}
        </div>

        <div className="mt-12 p-6 bg-blue-50 rounded-lg border border-blue-200">
          <h3 className="text-lg font-semibold text-blue-900 mb-2">
            Testing Instructions
          </h3>
          <ul className="text-blue-800 space-y-2 text-sm">
            <li>• Click any card to open that version in a new window</li>
            <li>• Test on both desktop and mobile devices</li>
            <li>• Explore all interactive elements in each version</li>
            <li>• Return to this gallery tab to view other versions</li>
          </ul>
        </div>

        <div className="mt-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Conditions We Treat
            </h2>
            <p className="text-lg text-gray-600">
              Learn about specific injuries and how Freedom Leg can help your recovery
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {injuryPages.map((injury) => (
              <Link
                key={injury.slug}
                to={injury.path}
                className="bg-white rounded-lg shadow-md hover:shadow-xl transition-all p-6 border-2 border-gray-100 hover:border-[#0f766e] group"
              >
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-xl font-bold text-gray-900 group-hover:text-[#0f766e] transition-colors flex-1">
                    {injury.title}
                  </h3>
                  <ArrowRight className="w-5 h-5 text-[#0f766e] opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 ml-2" />
                </div>
                <p className="text-gray-600 mb-3">
                  {injury.shortDescription}
                </p>
                <div className="flex items-center gap-2">
                  <span className="inline-block px-3 py-1 bg-[#f0fdfa] text-[#0f766e] text-xs font-medium rounded-full">
                    {injury.duration}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
