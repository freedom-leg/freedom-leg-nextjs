import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';
import { SEO } from '../components/SEO';

export function FootSurgeryPage() {
  const siteUrl = 'https://freedomleg.com';
  const canonicalUrl = `${siteUrl}/foot-surgery`;

  const structuredData = [
    {
      '@context': 'https://schema.org',
      '@type': 'MedicalCondition',
      name: 'Foot Surgery Recovery',
      alternateName: 'Foot Surgery',
      description: 'Various foot procedures including bunionectomy, fusion surgery, and wound care requiring 4-8 weeks of non-weight bearing.',
      possibleTreatment: {
        '@type': 'MedicalTherapy',
        name: 'Freedom Leg Hands-Free Crutch',
        description: 'Provides complete off-loading while allowing hands-free mobility during foot surgery recovery.',
      },
      url: canonicalUrl,
    },
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: siteUrl },
        { '@type': 'ListItem', position: 2, name: 'Foot Surgery Recovery', item: canonicalUrl },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title="Foot Surgery Recovery | Freedom Leg"
        description="Recovery from foot procedures including bunionectomy, fusion surgery, and wound care requiring 4-8 weeks non-weight bearing. Freedom Leg provides hands-free mobility."
        canonical={canonicalUrl}
        ogType="article"
        structuredData={structuredData}
      />

      <nav className="bg-gray-50 border-b border-gray-200 py-4 px-4">
        <div className="max-w-6xl mx-auto flex items-center gap-2 text-sm">
          <Link to="/" className="text-[#0f766e] hover:underline flex items-center gap-1">
            <Home className="w-4 h-4" />
            Home
          </Link>
          <ChevronRight className="w-4 h-4 text-gray-400" />
          <span className="text-gray-600">Foot Surgery Recovery</span>
        </div>
      </nav>

      <section className="py-16 px-4 bg-gradient-to-b from-[#f0fdfa] to-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-[#333]">
            Foot Surgery Recovery
          </h1>
          <p className="text-2xl md:text-3xl text-gray-600 mb-6">
            Hands-Free Mobility During Healing
          </p>
          <p className="text-xl leading-relaxed text-gray-700 mb-8">
            Various foot procedures including bunionectomy, fusion surgery, and wound care require 4-8 weeks of strict non-weight bearing for optimal healing.
          </p>
          <div className="flex flex-wrap gap-4 justify-center mb-8">
            <div className="bg-white px-6 py-3 rounded-lg border-2 border-[#0f766e]">
              <div className="text-sm text-gray-600">Typical Duration</div>
              <div className="text-lg font-bold text-[#0f766e]">4-8 weeks</div>
            </div>
            <div className="bg-[#0f766e] text-white px-6 py-3 rounded-lg">
              <div className="text-sm">Freedom Leg Status</div>
              <div className="text-lg font-bold">Suitable</div>
            </div>
          </div>
          <Link
            to="/"
            className="inline-block px-8 py-4 bg-[#0f766e] text-white font-bold uppercase tracking-wider rounded-lg hover:bg-[#0d5f5a] transition-all text-lg"
          >
            Get Your Freedom Leg
          </Link>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            Common Foot Surgeries Requiring Non-Weight Bearing
          </h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4">
            <p>
              Many foot procedures require a period of non-weight bearing to protect surgical repairs and allow proper healing. Common surgeries include:
            </p>
            <ul className="list-disc pl-8 space-y-2">
              <li><strong>Bunionectomy:</strong> Bunion removal surgery requiring 4-6 weeks of non-weight bearing</li>
              <li><strong>Foot Fusion Surgery:</strong> Arthrodesis procedures requiring 8-12 weeks of protected weight bearing</li>
              <li><strong>Plantar Wound Care:</strong> Ulcers or wounds on the bottom of the foot requiring complete pressure relief</li>
              <li><strong>Neuroma Surgery:</strong> Nerve removal requiring 4-6 weeks of protected weight bearing</li>
              <li><strong>Hammertoe Correction:</strong> Toe surgery requiring 4-6 weeks of non-weight bearing</li>
              <li><strong>Flatfoot Reconstruction:</strong> Complex procedures requiring extended non-weight bearing</li>
            </ul>
            <p>
              The specific non-weight bearing period depends on the procedure type, complexity, and your surgeon's protocol.
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#f0fdfa]">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            How Freedom Leg Helps Foot Surgery Recovery
          </h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4 mb-8">
            <p>
              Freedom Leg is essential for foot surgery recovery because it provides complete protection while maintaining your quality of life:
            </p>
            <ul className="list-disc pl-8 space-y-2">
              <li>Zero weight and pressure on the surgical site allows optimal healing</li>
              <li>Complete off-loading for plantar wounds and ulcers</li>
              <li>Protect delicate bone and soft tissue repairs</li>
              <li>Move freely throughout your home without risk to your surgical site</li>
              <li>Both hands remain free for daily activities and work</li>
              <li>Maintain independence during the 4-8 week recovery period</li>
            </ul>
          </div>
          <div className="bg-white p-6 rounded-lg border-l-4 border-[#0f766e]">
            <p className="text-xl font-medium text-[#0f766e]">
              Stay mobile after foot surgery while protecting your surgical site
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">Recovery Timeline</h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4">
            <p><strong>Weeks 0-2:</strong> Complete non-weight bearing in a surgical boot or cast. Focus on elevation, ice, and pain management. Keep surgical site clean and dry.</p>
            <p><strong>Weeks 2-4:</strong> Continued non-weight bearing with wound checks and suture removal. Physical therapy may begin for ankle range of motion.</p>
            <p><strong>Weeks 4-6:</strong> Ongoing non-weight bearing with progressive exercises. Freedom Leg provides crucial mobility during this healing phase.</p>
            <p><strong>Weeks 6-8:</strong> Gradual transition to partial weight bearing as directed by your surgeon based on healing progress and X-rays.</p>
            <p><strong>Weeks 8+:</strong> Progressive strengthening and return to normal activities. Full recovery typically takes 3-6 months depending on the procedure.</p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            Special Considerations for Plantar Wounds
          </h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4">
            <p>
              For patients with plantar wounds, ulcers, or diabetic foot complications, complete off-loading is absolutely critical for healing. Even minimal pressure can prevent wound closure and lead to complications.
            </p>
            <p>
              Freedom Leg provides the complete pressure relief necessary for plantar wound healing while allowing you to remain mobile and independent. This is especially important for patients who:
            </p>
            <ul className="list-disc pl-8 space-y-2">
              <li>Have diabetes and require extended wound healing time</li>
              <li>Need to avoid all pressure on the bottom of the foot</li>
              <li>Require long-term off-loading (weeks to months)</li>
              <li>Want to maintain quality of life during wound healing</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#0f766e] text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Experience Freedom During Recovery?
          </h2>
          <p className="text-xl mb-8 leading-relaxed">
            Join thousands who have recovered from foot surgery with Freedom Leg. Get back to your life with hands-free mobility.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/"
              className="inline-block px-8 py-4 bg-white text-[#0f766e] font-bold uppercase tracking-wider rounded-lg hover:bg-gray-100 transition-all text-lg"
            >
              Order Now
            </Link>
            <Link
              to="/"
              className="inline-block px-8 py-4 bg-transparent text-white font-bold uppercase tracking-wider rounded-lg border-2 border-white hover:bg-white hover:text-[#0f766e] transition-all text-lg"
            >
              Take the Quiz
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
