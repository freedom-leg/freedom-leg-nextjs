import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';
import { SEO } from '../components/SEO';

export function KneeSurgeryPage() {
  const siteUrl = 'https://freedomleg.com';
  const canonicalUrl = `${siteUrl}/knee-surgery`;

  const structuredData = [
    {
      '@context': 'https://schema.org',
      '@type': 'MedicalCondition',
      name: 'Knee Surgery Recovery',
      alternateName: 'Knee Surgery or Injury',
      description: 'Various knee procedures including microfracture, osteotomy, patellar fractures, and cartilage repair requiring 6-12 weeks of non-weight bearing.',
      possibleTreatment: {
        '@type': 'MedicalTherapy',
        name: 'Freedom Leg Hands-Free Crutch',
        description: 'Provides complete off-loading while allowing hands-free mobility during knee surgery recovery.',
      },
      url: canonicalUrl,
    },
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: siteUrl },
        { '@type': 'ListItem', position: 2, name: 'Knee Surgery Recovery', item: canonicalUrl },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title="Knee Surgery Recovery | Freedom Leg"
        description="Recovery from knee procedures including microfracture, osteotomy, patellar fractures requiring 6-12 weeks non-weight bearing. Freedom Leg provides hands-free mobility."
        canonical={canonicalUrl}
        ogType="article"
        structuredData={structuredData}
      />

      <nav className="bg-gray-50 border-b border-gray-200 py-4 px-4">
        <div className="max-w-6xl mx-auto flex items-center gap-2 text-sm">
          <Link to="/" className="text-[#0f766e] hover:underline flex items-center gap-1">
            <Home className="w-4 h-4" />
            Home
          </Link>
          <ChevronRight className="w-4 h-4 text-gray-400" />
          <span className="text-gray-600">Knee Surgery Recovery</span>
        </div>
      </nav>

      <section className="py-16 px-4 bg-gradient-to-b from-[#f0fdfa] to-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-[#333]">
            Knee Surgery Recovery
          </h1>
          <p className="text-2xl md:text-3xl text-gray-600 mb-6">
            Hands-Free Mobility During Healing
          </p>
          <p className="text-xl leading-relaxed text-gray-700 mb-8">
            Various knee procedures including microfracture, osteotomy, patellar fractures, and cartilage repair require 6-12 weeks of strict non-weight bearing for optimal healing.
          </p>
          <div className="flex flex-wrap gap-4 justify-center mb-8">
            <div className="bg-white px-6 py-3 rounded-lg border-2 border-[#0f766e]">
              <div className="text-sm text-gray-600">Typical Duration</div>
              <div className="text-lg font-bold text-[#0f766e]">6-12 weeks</div>
            </div>
            <div className="bg-[#0f766e] text-white px-6 py-3 rounded-lg">
              <div className="text-sm">Freedom Leg Status</div>
              <div className="text-lg font-bold">Suitable</div>
            </div>
          </div>
          <Link
            to="/"
            className="inline-block px-8 py-4 bg-[#0f766e] text-white font-bold uppercase tracking-wider rounded-lg hover:bg-[#0d5f5a] transition-all text-lg"
          >
            Get Your Freedom Leg
          </Link>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            Common Knee Surgeries Requiring Non-Weight Bearing
          </h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4">
            <p>
              Many knee procedures require an extended period of non-weight bearing to protect delicate surgical repairs and allow proper healing. Common surgeries include:
            </p>
            <ul className="list-disc pl-8 space-y-2">
              <li><strong>Microfracture Surgery:</strong> Cartilage repair technique requiring 6-8 weeks of strict non-weight bearing</li>
              <li><strong>Osteotomy:</strong> Bone realignment surgery requiring 8-12 weeks of protected weight bearing</li>
              <li><strong>Patellar Fractures:</strong> Kneecap breaks requiring 6-8 weeks of non-weight bearing</li>
              <li><strong>Meniscus Repair:</strong> Complex tears requiring 4-6 weeks of protected weight bearing</li>
              <li><strong>Cartilage Transplantation:</strong> Extensive cartilage repairs requiring extended non-weight bearing</li>
            </ul>
            <p>
              The specific non-weight bearing period depends on the procedure type, severity of injury, and your surgeon's protocol.
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#f0fdfa]">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            How Freedom Leg Helps Knee Surgery Recovery
          </h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4 mb-8">
            <p>
              Freedom Leg is essential for knee surgery recovery because it provides complete protection while maintaining your quality of life:
            </p>
            <ul className="list-disc pl-8 space-y-2">
              <li>Zero weight on the surgical site allows optimal healing</li>
              <li>Protect delicate cartilage repairs and bone realignment</li>
              <li>Move freely without risk of accidental weight bearing</li>
              <li>Both hands remain free for daily activities and work</li>
              <li>Reduce risk of secondary injuries from crutch use</li>
              <li>Maintain independence during the 6-12 week recovery period</li>
            </ul>
          </div>
          <div className="bg-white p-6 rounded-lg border-l-4 border-[#0f766e]">
            <p className="text-xl font-medium text-[#0f766e]">
              Keep all weight off your knee while moving freely throughout recovery
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">Recovery Timeline</h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4">
            <p><strong>Weeks 0-2:</strong> Complete non-weight bearing in a brace or immobilizer. Focus on pain management and preventing blood clots.</p>
            <p><strong>Weeks 2-6:</strong> Continued non-weight bearing with physical therapy for range of motion. Freedom Leg allows safe mobility during this critical healing phase.</p>
            <p><strong>Weeks 6-12:</strong> Gradual transition to partial weight bearing as directed by your surgeon. Progressive strengthening begins.</p>
            <p><strong>Weeks 12+:</strong> Advanced strengthening and return to activities. Full recovery typically takes 4-6 months depending on the procedure.</p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#0f766e] text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Experience Freedom During Recovery?
          </h2>
          <p className="text-xl mb-8 leading-relaxed">
            Join thousands who have recovered from knee surgery with Freedom Leg. Get back to your life with hands-free mobility.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/"
              className="inline-block px-8 py-4 bg-white text-[#0f766e] font-bold uppercase tracking-wider rounded-lg hover:bg-gray-100 transition-all text-lg"
            >
              Order Now
            </Link>
            <Link
              to="/"
              className="inline-block px-8 py-4 bg-transparent text-white font-bold uppercase tracking-wider rounded-lg border-2 border-white hover:bg-white hover:text-[#0f766e] transition-all text-lg"
            >
              Take the Quiz
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
