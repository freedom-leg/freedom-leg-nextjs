import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';
import { SEO } from '../components/SEO';

export function LowerLegFracturePage() {
  const siteUrl = 'https://freedomleg.com';
  const canonicalUrl = `${siteUrl}/lower-leg-fracture`;

  const structuredData = [
    {
      '@context': 'https://schema.org',
      '@type': 'MedicalCondition',
      name: 'Lower Leg Fracture',
      alternateName: 'Shin or Tibia Fracture',
      description: 'Fractures of the tibia (shinbone) requiring 8-12 weeks of complete off-loading during healing.',
      possibleTreatment: {
        '@type': 'MedicalTherapy',
        name: 'Freedom Leg Hands-Free Crutch',
        description: 'Provides complete off-loading while allowing hands-free mobility during tibia fracture recovery.',
      },
      url: canonicalUrl,
    },
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: siteUrl },
        { '@type': 'ListItem', position: 2, name: 'Lower Leg Fracture Recovery', item: canonicalUrl },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title="Lower Leg Fracture Recovery | Freedom Leg"
        description="Tibia (shinbone) fractures requiring 8-12 weeks of non-weight bearing. Freedom Leg provides hands-free mobility while keeping all weight off your healing fracture."
        canonical={canonicalUrl}
        ogType="article"
        structuredData={structuredData}
      />

      <nav className="bg-gray-50 border-b border-gray-200 py-4 px-4">
        <div className="max-w-6xl mx-auto flex items-center gap-2 text-sm">
          <Link to="/" className="text-[#0f766e] hover:underline flex items-center gap-1">
            <Home className="w-4 h-4" />
            Home
          </Link>
          <ChevronRight className="w-4 h-4 text-gray-400" />
          <span className="text-gray-600">Lower Leg Fracture</span>
        </div>
      </nav>

      <section className="py-16 px-4 bg-gradient-to-b from-[#f0fdfa] to-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-[#333]">
            Lower Leg Fracture Recovery
          </h1>
          <p className="text-2xl md:text-3xl text-gray-600 mb-6">
            Hands-Free Mobility During Healing
          </p>
          <p className="text-xl leading-relaxed text-gray-700 mb-8">
            Fractures of the tibia (shinbone) require 8-12 weeks of complete off-loading to allow proper bone healing. Freedom Leg provides hands-free mobility during this extended recovery period.
          </p>
          <div className="flex flex-wrap gap-4 justify-center mb-8">
            <div className="bg-white px-6 py-3 rounded-lg border-2 border-[#0f766e]">
              <div className="text-sm text-gray-600">Typical Duration</div>
              <div className="text-lg font-bold text-[#0f766e]">8-12 weeks</div>
            </div>
            <div className="bg-[#0f766e] text-white px-6 py-3 rounded-lg">
              <div className="text-sm">Freedom Leg Status</div>
              <div className="text-lg font-bold">Suitable</div>
            </div>
          </div>
          <Link
            to="/"
            className="inline-block px-8 py-4 bg-[#0f766e] text-white font-bold uppercase tracking-wider rounded-lg hover:bg-[#0d5f5a] transition-all text-lg"
          >
            Get Your Freedom Leg
          </Link>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            What are Lower Leg Fractures?
          </h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4">
            <p>
              The tibia, commonly known as the shinbone, is the larger of the two bones in your lower leg. Tibial fractures are common injuries that can occur anywhere along the bone and typically result from high-impact trauma, sports injuries, or falls.
            </p>
            <p>
              Common types of tibial fractures include:
            </p>
            <ul className="list-disc pl-8 space-y-2">
              <li><strong>Proximal Tibial Fractures:</strong> Breaks near the top of the shinbone close to the knee</li>
              <li><strong>Midshaft Tibial Fractures:</strong> Breaks in the middle section of the shinbone</li>
              <li><strong>Distal Tibial Fractures:</strong> Breaks near the ankle</li>
              <li><strong>Tibial Plateau Fractures:</strong> Fractures involving the knee joint surface</li>
              <li><strong>Stress Fractures:</strong> Small cracks from repetitive stress</li>
            </ul>
            <p>
              Most tibial fractures require 8-12 weeks of strict non-weight bearing to allow proper bone healing and prevent displacement or malunion.
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#f0fdfa]">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            How Freedom Leg Helps Lower Leg Fracture Recovery
          </h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4 mb-8">
            <p>
              Freedom Leg is essential for tibial fracture recovery because it provides complete protection during the critical 8-12 week healing period:
            </p>
            <ul className="list-disc pl-8 space-y-2">
              <li>Zero weight on the fractured bone allows optimal bone healing</li>
              <li>Prevents displacement of fracture fragments</li>
              <li>Move freely throughout your home and workplace with both hands free</li>
              <li>Maintain independence during the extended recovery period</li>
              <li>Reduce risk of secondary injuries from crutch-related falls</li>
              <li>Continue working and caring for family members</li>
            </ul>
          </div>
          <div className="bg-white p-6 rounded-lg border-l-4 border-[#0f766e]">
            <p className="text-xl font-medium text-[#0f766e]">
              Walk freely while your shin fracture heals with complete weight protection
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">Recovery Timeline</h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4">
            <p><strong>Weeks 0-2:</strong> Complete non-weight bearing in a cast or boot. Initial swelling and pain management. Regular monitoring for compartment syndrome if applicable.</p>
            <p><strong>Weeks 2-6:</strong> Continued strict non-weight bearing with regular X-rays to monitor healing progress. Physical therapy may begin for upper body and core strength.</p>
            <p><strong>Weeks 6-10:</strong> Ongoing non-weight bearing with progressive range of motion exercises for the ankle and knee. Freedom Leg provides crucial mobility during this phase.</p>
            <p><strong>Weeks 10-12:</strong> Gradual transition to partial weight bearing as directed by your orthopedic surgeon based on X-ray evidence of healing.</p>
            <p><strong>Weeks 12+:</strong> Progressive strengthening and return to normal activities. Full recovery typically takes 4-6 months.</p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#0f766e] text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Experience Freedom During Recovery?
          </h2>
          <p className="text-xl mb-8 leading-relaxed">
            Join thousands who have recovered from lower leg fractures with Freedom Leg. Get back to your life with hands-free mobility.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/"
              className="inline-block px-8 py-4 bg-white text-[#0f766e] font-bold uppercase tracking-wider rounded-lg hover:bg-gray-100 transition-all text-lg"
            >
              Order Now
            </Link>
            <Link
              to="/"
              className="inline-block px-8 py-4 bg-transparent text-white font-bold uppercase tracking-wider rounded-lg border-2 border-white hover:bg-white hover:text-[#0f766e] transition-all text-lg"
            >
              Take the Quiz
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
