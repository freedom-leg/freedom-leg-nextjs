import { Header } from '../components/Header';
import { Hero } from '../components/Hero';
import { ReviewSection } from '../components/ReviewSection';
import { QuizSection } from '../components/inline/QuizSection';
import { VideoSection } from '../components/inline/VideoSection';
import { ComparisonSection } from '../components/inline/ComparisonSection';
import { HowItWorksSection } from '../components/inline/HowItWorksSection';
import { FAQSection } from '../components/inline/FAQSection';
import { OrderSection } from '../components/inline/OrderSection';

export function InlineVersion() {
  return (
    <div className="min-h-screen overflow-x-hidden max-w-full">
      <Header />
      <Hero />
      <QuizSection />
      <VideoSection />
      <HowItWorksSection />
      <ComparisonSection />
      <FAQSection />
      <ReviewSection />
      <OrderSection />
    </div>
  );
}
