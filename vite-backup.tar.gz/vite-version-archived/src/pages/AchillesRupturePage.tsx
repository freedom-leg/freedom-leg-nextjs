import { Link } from 'react-router-dom';
import { ChevronRight, Home, ArrowRight } from 'lucide-react';
import { SEO } from '../components/SEO';

export function AchillesRupturePage() {
  const scrollToOrder = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const siteUrl = 'https://freedomleg.com';
  const canonicalUrl = `${siteUrl}/achilles-rupture`;

  const structuredData = [
    {
      '@context': 'https://schema.org',
      '@type': 'MedicalCondition',
      name: 'Achilles Tendon Rupture',
      alternateName: 'Achilles Tear or Rupture',
      description: 'Complete or partial tear of the Achilles tendon connecting the calf muscles to the heel bone. This injury typically requires 6-12 weeks of non-weight bearing recovery.',
      possibleTreatment: {
        '@type': 'MedicalTherapy',
        name: 'Freedom Leg Hands-Free Crutch',
        description: 'Provides complete off-loading of the injured leg while allowing hands-free mobility during Achilles tendon recovery.',
      },
      url: canonicalUrl,
    },
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: siteUrl },
        { '@type': 'ListItem', position: 2, name: 'Achilles Tendon Rupture Recovery', item: canonicalUrl },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title="Achilles Tendon Rupture Recovery | Freedom Leg"
        description="Complete or partial tear of the Achilles tendon requiring 6-12 weeks of non-weight bearing. Freedom Leg provides hands-free mobility during Achilles recovery without stress on the tendon."
        canonical={canonicalUrl}
        ogType="article"
        structuredData={structuredData}
      />

      <nav className="bg-gray-50 border-b border-gray-200 py-4 px-4">
        <div className="max-w-6xl mx-auto flex items-center gap-2 text-sm">
          <Link to="/" className="text-[#0f766e] hover:underline flex items-center gap-1">
            <Home className="w-4 h-4" />
            Home
          </Link>
          <ChevronRight className="w-4 h-4 text-gray-400" />
          <span className="text-gray-600">Achilles Tendon Rupture</span>
        </div>
      </nav>

      <section className="py-16 px-4 bg-gradient-to-b from-[#f0fdfa] to-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-[#333]">
            Achilles Tendon Rupture Recovery
          </h1>
          <p className="text-2xl md:text-3xl text-gray-600 mb-6">
            Hands-Free Mobility During Healing
          </p>
          <p className="text-xl leading-relaxed text-gray-700 mb-8">
            Complete or partial tear of the Achilles tendon connecting the calf to the heel. This injury typically requires 6-12 weeks of strict non-weight bearing to allow proper healing.
          </p>
          <div className="flex flex-wrap gap-4 justify-center mb-8">
            <div className="bg-white px-6 py-3 rounded-lg border-2 border-[#0f766e]">
              <div className="text-sm text-gray-600">Typical Duration</div>
              <div className="text-lg font-bold text-[#0f766e]">6-12 weeks</div>
            </div>
            <div className="bg-[#0f766e] text-white px-6 py-3 rounded-lg">
              <div className="text-sm">Freedom Leg Status</div>
              <div className="text-lg font-bold">Suitable</div>
            </div>
          </div>
          <Link
            to="/"
            className="inline-block px-8 py-4 bg-[#0f766e] text-white font-bold uppercase tracking-wider rounded-lg hover:bg-[#0d5f5a] transition-all text-lg"
          >
            Get Your Freedom Leg
          </Link>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            What is an Achilles Tendon Rupture?
          </h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4">
            <p>
              The Achilles tendon is the largest and strongest tendon in your body, connecting your calf muscles to your heel bone. An Achilles rupture occurs when this tendon tears, either partially or completely. This injury is most common in people aged 30-50 and often happens during sports or activities that involve sudden acceleration or jumping.
            </p>
            <p>
              Most people describe hearing a "pop" or feeling like they were kicked in the back of the leg when the rupture occurs. The injury typically results in immediate pain, swelling, and difficulty walking or standing on your toes.
            </p>
            <p>
              Whether treated surgically or conservatively, Achilles ruptures require an extended period of non-weight bearing (typically 6-12 weeks) to allow the tendon to heal properly without re-injury.
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#f0fdfa]">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            How Freedom Leg Helps Achilles Recovery
          </h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4 mb-8">
            <p>
              Freedom Leg provides complete off-loading of your injured leg while allowing you to maintain a natural walking motion with both hands free. This is crucial during Achilles recovery because:
            </p>
            <ul className="list-disc pl-8 space-y-2">
              <li>Zero weight or stress is placed on the healing Achilles tendon</li>
              <li>You can move freely throughout your home and work without crutches</li>
              <li>Both hands remain free for daily activities and work tasks</li>
              <li>Natural gait pattern helps prevent secondary injuries from awkward crutch walking</li>
              <li>Increased independence during the long 6-12 week recovery period</li>
            </ul>
          </div>
          <div className="bg-white p-6 rounded-lg border-l-4 border-[#0f766e]">
            <p className="text-xl font-medium text-[#0f766e]">
              Walk hands-free while keeping all weight off your healing Achilles tendon
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">Recovery Timeline</h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4">
            <p><strong>Weeks 0-2:</strong> Complete non-weight bearing in a cast or boot. The leg is typically positioned with the foot pointed downward to reduce tension on the tendon.</p>
            <p><strong>Weeks 2-6:</strong> Continued non-weight bearing with gradual ankle positioning changes. Physical therapy may begin with passive range of motion exercises.</p>
            <p><strong>Weeks 6-12:</strong> Gradual transition to partial weight bearing as directed by your surgeon. The Freedom Leg provides crucial support during this entire period.</p>
            <p><strong>Weeks 12+:</strong> Progressive strengthening and return to activities. Full recovery typically takes 6-12 months.</p>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            Freedom Leg vs Traditional Crutches
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg border-2 border-gray-200">
              <h3 className="text-xl font-bold mb-4 text-gray-500">Traditional Crutches</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-red-500 font-bold mt-1">✗</span>
                  <span>Hands occupied and unable to carry items</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 font-bold mt-1">✗</span>
                  <span>Upper body fatigue and shoulder pain</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 font-bold mt-1">✗</span>
                  <span>Risk of falls on stairs or uneven surfaces</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 font-bold mt-1">✗</span>
                  <span>Difficulty performing work tasks</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 font-bold mt-1">✗</span>
                  <span>Limited mobility around the home</span>
                </li>
              </ul>
            </div>
            <div className="bg-[#f0fdfa] p-6 rounded-lg border-2 border-[#0f766e]">
              <h3 className="text-xl font-bold mb-4 text-[#0f766e]">Freedom Leg</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-[#0f766e] font-bold mt-1">✓</span>
                  <span>Both hands completely free</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#0f766e] font-bold mt-1">✓</span>
                  <span>No upper body strain or fatigue</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#0f766e] font-bold mt-1">✓</span>
                  <span>Safe on stairs and all surfaces</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#0f766e] font-bold mt-1">✓</span>
                  <span>Maintain work productivity</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#0f766e] font-bold mt-1">✓</span>
                  <span>Full mobility and independence</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 text-[#333]">
            Is Freedom Leg Right for Your Achilles Rupture?
          </h2>
          <div className="text-lg leading-relaxed text-gray-700 space-y-4 mb-6">
            <p>
              Freedom Leg is ideal for anyone recovering from an Achilles tendon rupture who needs to maintain mobility during the 6-12 week non-weight bearing period. Whether you're recovering from surgical repair or conservative treatment, Freedom Leg allows you to:
            </p>
            <ul className="list-disc pl-8 space-y-2">
              <li>Continue working from home or at the office</li>
              <li>Care for children or family members</li>
              <li>Maintain household responsibilities</li>
              <li>Move safely between rooms without assistance</li>
              <li>Preserve your independence during recovery</li>
            </ul>
          </div>
          <div className="bg-amber-50 border-l-4 border-amber-500 p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-3 text-amber-900">
              Important Considerations
            </h3>
            <div className="text-base text-amber-900">
              <p>Always follow your surgeon's or physician's specific weight-bearing instructions. Freedom Leg is designed for complete non-weight bearing use. Consult your healthcare provider before using any mobility device during recovery.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#0f766e] text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Experience Freedom During Recovery?
          </h2>
          <p className="text-xl mb-8 leading-relaxed">
            Join thousands who have recovered from Achilles ruptures with the Freedom Leg. Get back to your life with hands-free mobility.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/"
              className="inline-block px-8 py-4 bg-white text-[#0f766e] font-bold uppercase tracking-wider rounded-lg hover:bg-gray-100 transition-all text-lg"
            >
              Order Now
            </Link>
            <Link
              to="/"
              className="inline-block px-8 py-4 bg-transparent text-white font-bold uppercase tracking-wider rounded-lg border-2 border-white hover:bg-white hover:text-[#0f766e] transition-all text-lg"
            >
              Take the Quiz
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
