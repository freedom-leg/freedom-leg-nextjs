export interface Injury {
  id: string;
  injury_name: string;
  common_name: string;
  slug: string;
  category: 'foot-ankle' | 'lower-leg' | 'knee' | 'other';
  body_region: 'foot' | 'ankle' | 'lower-leg' | 'knee' | 'multiple';
  short_description: string | null;
  non_weight_bearing_duration: string | null;
  freedom_leg_suitable: boolean;
  key_benefit_one_liner: string | null;
  full_description: string | null;
  how_freedom_leg_helps: string | null;
  weight_bearing_progression: string | null;
  recovery_comparison: string | null;
  ideal_candidate_description: string | null;
  contraindications: string | null;
  faq_items: Array<{ question: string; answer: string }>;
  related_injury_ids: string[];
  seo_title: string | null;
  seo_description: string | null;
  meta_keywords: string[];
  search_keywords: string[];
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}
